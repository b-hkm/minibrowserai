main.o: main.cpp app/browser.h app/../html/parser.h app/../css/style.h \
 app/../js/jsengine.h app/../layout/layout.h app/../layout/resource.h \
 app/../render/renderer.h app/../net/fetch.h app/../media/mediaplayer.h \
 layout/font_loader.h render/window.h tests/selftest.h
app/browser.h:
app/../html/parser.h:
app/../css/style.h:
app/../js/jsengine.h:
app/../layout/layout.h:
app/../layout/resource.h:
app/../render/renderer.h:
app/../net/fetch.h:
app/../media/mediaplayer.h:
layout/font_loader.h:
render/window.h:
tests/selftest.h:
